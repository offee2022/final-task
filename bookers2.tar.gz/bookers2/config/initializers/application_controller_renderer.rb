# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '2ea31d31d3247bb0d89904f723371813d06ce285fef6f8e5840fc9a6cbf3b3bab549910277cfe9c64bd2bebf9f030958eb596eb9f5e6a7026d39f207a29298f8'